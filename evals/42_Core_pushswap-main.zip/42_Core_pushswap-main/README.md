# 42_Core_pushswap
A project in the "second circle" at 42 schools concerning number sorting using two stacks.
