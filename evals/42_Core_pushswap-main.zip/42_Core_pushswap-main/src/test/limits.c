#include <limits.h>
#include <stdio.h>

int main()
{
	printf("Int Max: %+d\n", INT_MAX);
	printf("Int Min: %d\n", INT_MIN);
	printf("Long Int Max: %+ld\n", LONG_MAX);
	printf("Long Int Min: %ld\n", LONG_MIN);
	return 0;
}